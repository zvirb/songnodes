--
-- PostgreSQL database dump
--

\restrict DZSddrVULP5X9xIOR3qhJw4qhkHhQU8w9SLp1ezTO01n1PdGAAtMKWiCHmRtWyL

-- Dumped from database version 15.14
-- Dumped by pg_dump version 15.14

-- Started on 2025-08-19 12:25:33 UTC

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 9 (class 2615 OID 16913)
-- Name: musicdb; Type: SCHEMA; Schema: -; Owner: musicdb_user
--

CREATE SCHEMA musicdb;


ALTER SCHEMA musicdb OWNER TO musicdb_user;

--
-- TOC entry 4 (class 3079 OID 16477)
-- Name: btree_gin; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS btree_gin WITH SCHEMA public;


--
-- TOC entry 3967 (class 0 OID 0)
-- Dependencies: 4
-- Name: EXTENSION btree_gin; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION btree_gin IS 'support for indexing common datatypes in GIN';


--
-- TOC entry 3 (class 3079 OID 16396)
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- TOC entry 3968 (class 0 OID 0)
-- Dependencies: 3
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


--
-- TOC entry 2 (class 3079 OID 16385)
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- TOC entry 3969 (class 0 OID 0)
-- Dependencies: 2
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- TOC entry 387 (class 1255 OID 24669)
-- Name: bulk_insert_edges(jsonb); Type: FUNCTION; Schema: musicdb; Owner: musicdb_user
--

CREATE FUNCTION musicdb.bulk_insert_edges(edge_data jsonb) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
    inserted_count INTEGER;
BEGIN
    WITH bulk_insert AS (
        INSERT INTO edges (source_id, target_id, weight, edge_type, metadata)
        SELECT 
            (value->>'source_id')::UUID,
            (value->>'target_id')::UUID,
            COALESCE((value->>'weight')::FLOAT, 1.0),
            COALESCE(value->>'edge_type', 'similarity'),
            COALESCE(value->'metadata', '{}'::JSONB)
        FROM jsonb_array_elements(edge_data) AS value
        ON CONFLICT (source_id, target_id, edge_type) DO UPDATE SET
            weight = EXCLUDED.weight,
            metadata = EXCLUDED.metadata
        RETURNING 1
    )
    SELECT COUNT(*) INTO inserted_count FROM bulk_insert;
    RETURN inserted_count;
END;
$$;


ALTER FUNCTION musicdb.bulk_insert_edges(edge_data jsonb) OWNER TO musicdb_user;

--
-- TOC entry 390 (class 1255 OID 24668)
-- Name: bulk_insert_nodes(jsonb); Type: FUNCTION; Schema: musicdb; Owner: musicdb_user
--

CREATE FUNCTION musicdb.bulk_insert_nodes(node_data jsonb) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
    inserted_count INTEGER;
BEGIN
    WITH bulk_insert AS (
        INSERT INTO nodes (track_id, x_position, y_position, metadata)
        SELECT 
            (value->>'track_id')::UUID,
            COALESCE((value->>'x')::FLOAT, 0),
            COALESCE((value->>'y')::FLOAT, 0),
            COALESCE(value->'metadata', '{}'::JSONB)
        FROM jsonb_array_elements(node_data) AS value
        ON CONFLICT (track_id) DO UPDATE SET
            x_position = EXCLUDED.x_position,
            y_position = EXCLUDED.y_position,
            metadata = EXCLUDED.metadata,
            updated_at = NOW()
        RETURNING 1
    )
    SELECT COUNT(*) INTO inserted_count FROM bulk_insert;
    RETURN inserted_count;
END;
$$;


ALTER FUNCTION musicdb.bulk_insert_nodes(node_data jsonb) OWNER TO musicdb_user;

--
-- TOC entry 388 (class 1255 OID 24670)
-- Name: calculate_graph_metrics(); Type: FUNCTION; Schema: musicdb; Owner: musicdb_user
--

CREATE FUNCTION musicdb.calculate_graph_metrics() RETURNS TABLE(total_nodes bigint, total_edges bigint, avg_degree double precision, density double precision, calculated_at timestamp with time zone)
    LANGUAGE plpgsql
    AS $$
DECLARE
    node_count BIGINT;
    edge_count BIGINT;
    max_possible_edges BIGINT;
BEGIN
    SELECT COUNT(*) INTO node_count FROM nodes;
    SELECT COUNT(*) INTO edge_count FROM edges;
    
    -- Calculate maximum possible edges for undirected graph
    max_possible_edges := node_count * (node_count - 1) / 2;
    
    RETURN QUERY
    SELECT 
        node_count,
        edge_count,
        CASE 
            WHEN node_count > 0 THEN (2.0 * edge_count / node_count)
            ELSE 0.0 
        END as avg_degree,
        CASE 
            WHEN max_possible_edges > 0 THEN (edge_count::FLOAT / max_possible_edges)
            ELSE 0.0 
        END as density,
        NOW();
END;
$$;


ALTER FUNCTION musicdb.calculate_graph_metrics() OWNER TO musicdb_user;

--
-- TOC entry 384 (class 1255 OID 17216)
-- Name: extract_mashup_components(text); Type: FUNCTION; Schema: musicdb; Owner: musicdb_user
--

CREATE FUNCTION musicdb.extract_mashup_components(mashup_text text) RETURNS jsonb
    LANGUAGE plpgsql IMMUTABLE
    AS $$
DECLARE
    components JSONB := '[]'::JSONB;
    component TEXT;
BEGIN
    -- Split by common mashup delimiters
    FOREACH component IN ARRAY string_to_array(mashup_text, ' vs. ')
    LOOP
        components := components || jsonb_build_object('track', component, 'type', 'mashup');
    END LOOP;
    RETURN components;
END;
$$;


ALTER FUNCTION musicdb.extract_mashup_components(mashup_text text) OWNER TO musicdb_user;

--
-- TOC entry 383 (class 1255 OID 17215)
-- Name: normalize_text(text); Type: FUNCTION; Schema: musicdb; Owner: musicdb_user
--

CREATE FUNCTION musicdb.normalize_text(input_text text) RETURNS text
    LANGUAGE plpgsql IMMUTABLE
    AS $$
BEGIN
    RETURN LOWER(TRIM(REGEXP_REPLACE(input_text, '\s+', ' ', 'g')));
END;
$$;


ALTER FUNCTION musicdb.normalize_text(input_text text) OWNER TO musicdb_user;

--
-- TOC entry 389 (class 1255 OID 24671)
-- Name: refresh_graph_views(); Type: FUNCTION; Schema: musicdb; Owner: musicdb_user
--

CREATE FUNCTION musicdb.refresh_graph_views() RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    REFRESH MATERIALIZED VIEW CONCURRENTLY graph_popular_tracks;
    REFRESH MATERIALIZED VIEW CONCURRENTLY node_centrality;
END;
$$;


ALTER FUNCTION musicdb.refresh_graph_views() OWNER TO musicdb_user;

--
-- TOC entry 386 (class 1255 OID 17221)
-- Name: update_artist_search_vector(); Type: FUNCTION; Schema: musicdb; Owner: musicdb_user
--

CREATE FUNCTION musicdb.update_artist_search_vector() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.search_vector := to_tsvector('english', coalesce(NEW.name, '') || ' ' || coalesce(NEW.normalized_name, ''));
    RETURN NEW;
END;
$$;


ALTER FUNCTION musicdb.update_artist_search_vector() OWNER TO musicdb_user;

--
-- TOC entry 385 (class 1255 OID 17219)
-- Name: update_track_search_vector(); Type: FUNCTION; Schema: musicdb; Owner: musicdb_user
--

CREATE FUNCTION musicdb.update_track_search_vector() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.search_vector := to_tsvector('english', coalesce(NEW.title, '') || ' ' || coalesce(NEW.normalized_title, ''));
    RETURN NEW;
END;
$$;


ALTER FUNCTION musicdb.update_track_search_vector() OWNER TO musicdb_user;

--
-- TOC entry 382 (class 1255 OID 17206)
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: musicdb; Owner: musicdb_user
--

CREATE FUNCTION musicdb.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION musicdb.update_updated_at_column() OWNER TO musicdb_user;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 222 (class 1259 OID 16995)
-- Name: album_tracks; Type: TABLE; Schema: musicdb; Owner: musicdb_user
--

CREATE TABLE musicdb.album_tracks (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    album_id uuid NOT NULL,
    track_id uuid NOT NULL,
    track_number integer,
    disc_number integer DEFAULT 1,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE musicdb.album_tracks OWNER TO musicdb_user;

--
-- TOC entry 221 (class 1259 OID 16976)
-- Name: albums; Type: TABLE; Schema: musicdb; Owner: musicdb_user
--

CREATE TABLE musicdb.albums (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    title character varying(255) NOT NULL,
    artist_id uuid,
    release_date date,
    label character varying(255),
    spotify_id character varying(100),
    apple_music_id character varying(100),
    total_tracks integer,
    album_type character varying(50),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    metadata jsonb DEFAULT '{}'::jsonb
);


ALTER TABLE musicdb.albums OWNER TO musicdb_user;

--
-- TOC entry 218 (class 1259 OID 16914)
-- Name: artists; Type: TABLE; Schema: musicdb; Owner: musicdb_user
--

CREATE TABLE musicdb.artists (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255) NOT NULL,
    normalized_name character varying(255) NOT NULL,
    aliases text[],
    spotify_id character varying(100),
    apple_music_id character varying(100),
    soundcloud_id character varying(100),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    metadata jsonb DEFAULT '{}'::jsonb,
    search_vector tsvector
);


ALTER TABLE musicdb.artists OWNER TO musicdb_user;

--
-- TOC entry 220 (class 1259 OID 16952)
-- Name: track_artists; Type: TABLE; Schema: musicdb; Owner: musicdb_user
--

CREATE TABLE musicdb.track_artists (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    track_id uuid NOT NULL,
    artist_id uuid NOT NULL,
    role character varying(50) NOT NULL,
    "position" integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT track_artists_role_check CHECK (((role)::text = ANY ((ARRAY['primary'::character varying, 'featured'::character varying, 'remixer'::character varying, 'producer'::character varying, 'vocalist'::character varying])::text[])))
);


ALTER TABLE musicdb.track_artists OWNER TO musicdb_user;

--
-- TOC entry 219 (class 1259 OID 16929)
-- Name: tracks; Type: TABLE; Schema: musicdb; Owner: musicdb_user
--

CREATE TABLE musicdb.tracks (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    title character varying(500) NOT NULL,
    normalized_title character varying(500) NOT NULL,
    isrc character varying(12),
    spotify_id character varying(100),
    apple_music_id character varying(100),
    tidal_id character varying(100),
    duration_ms integer,
    bpm numeric(5,2),
    key character varying(10),
    energy numeric(3,2),
    danceability numeric(3,2),
    valence numeric(3,2),
    release_date date,
    genre character varying(100),
    subgenre character varying(100),
    mashup_components jsonb,
    is_remix boolean DEFAULT false,
    is_mashup boolean DEFAULT false,
    is_live boolean DEFAULT false,
    is_cover boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    metadata jsonb DEFAULT '{}'::jsonb,
    search_vector tsvector
);


ALTER TABLE musicdb.tracks OWNER TO musicdb_user;

--
-- TOC entry 233 (class 1259 OID 17197)
-- Name: artist_collaborations; Type: MATERIALIZED VIEW; Schema: musicdb; Owner: musicdb_user
--

CREATE MATERIALIZED VIEW musicdb.artist_collaborations AS
 SELECT a1.id AS artist1_id,
    a1.name AS artist1_name,
    a2.id AS artist2_id,
    a2.name AS artist2_name,
    count(DISTINCT ta1.track_id) AS collaboration_count,
    array_agg(DISTINCT t.title ORDER BY t.title) AS track_titles
   FROM ((((musicdb.track_artists ta1
     JOIN musicdb.track_artists ta2 ON (((ta1.track_id = ta2.track_id) AND (ta1.artist_id < ta2.artist_id))))
     JOIN musicdb.artists a1 ON ((ta1.artist_id = a1.id)))
     JOIN musicdb.artists a2 ON ((ta2.artist_id = a2.id)))
     JOIN musicdb.tracks t ON ((ta1.track_id = t.id)))
  GROUP BY a1.id, a1.name, a2.id, a2.name
  ORDER BY (count(DISTINCT ta1.track_id)) DESC
  WITH NO DATA;


ALTER TABLE musicdb.artist_collaborations OWNER TO musicdb_user;

--
-- TOC entry 231 (class 1259 OID 17174)
-- Name: data_quality_issues; Type: TABLE; Schema: musicdb; Owner: musicdb_user
--

CREATE TABLE musicdb.data_quality_issues (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    entity_type character varying(50) NOT NULL,
    entity_id uuid,
    issue_type character varying(100) NOT NULL,
    severity character varying(20) DEFAULT 'low'::character varying NOT NULL,
    description text,
    suggested_fix text,
    is_resolved boolean DEFAULT false,
    resolved_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE musicdb.data_quality_issues OWNER TO musicdb_user;

--
-- TOC entry 242 (class 1259 OID 24693)
-- Name: edges; Type: TABLE; Schema: musicdb; Owner: musicdb_user
--

CREATE TABLE musicdb.edges (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    source_id uuid NOT NULL,
    target_id uuid NOT NULL,
    weight double precision DEFAULT 1.0,
    edge_type character varying(50) DEFAULT 'similarity'::character varying NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT edges_weight_check CHECK ((weight >= (0)::double precision)),
    CONSTRAINT no_self_loops CHECK ((source_id <> target_id))
);


ALTER TABLE musicdb.edges OWNER TO musicdb_user;

--
-- TOC entry 225 (class 1259 OID 17048)
-- Name: events; Type: TABLE; Schema: musicdb; Owner: musicdb_user
--

CREATE TABLE musicdb.events (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255) NOT NULL,
    venue_id uuid,
    event_date date,
    event_type character varying(50),
    source character varying(50),
    source_url text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    metadata jsonb DEFAULT '{}'::jsonb
);


ALTER TABLE musicdb.events OWNER TO musicdb_user;

--
-- TOC entry 241 (class 1259 OID 24672)
-- Name: nodes; Type: TABLE; Schema: musicdb; Owner: musicdb_user
--

CREATE TABLE musicdb.nodes (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    track_id uuid NOT NULL,
    x_position double precision DEFAULT 0 NOT NULL,
    y_position double precision DEFAULT 0 NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE musicdb.nodes OWNER TO musicdb_user;

--
-- TOC entry 223 (class 1259 OID 17017)
-- Name: performers; Type: TABLE; Schema: musicdb; Owner: musicdb_user
--

CREATE TABLE musicdb.performers (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255) NOT NULL,
    normalized_name character varying(255) NOT NULL,
    artist_id uuid,
    bio text,
    country character varying(100),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    metadata jsonb DEFAULT '{}'::jsonb
);


ALTER TABLE musicdb.performers OWNER TO musicdb_user;

--
-- TOC entry 229 (class 1259 OID 17136)
-- Name: playlist_tracks; Type: TABLE; Schema: musicdb; Owner: musicdb_user
--

CREATE TABLE musicdb.playlist_tracks (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    playlist_id uuid NOT NULL,
    track_id uuid NOT NULL,
    "position" integer,
    added_at timestamp with time zone,
    added_by character varying(255),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE musicdb.playlist_tracks OWNER TO musicdb_user;

--
-- TOC entry 228 (class 1259 OID 17121)
-- Name: playlists; Type: TABLE; Schema: musicdb; Owner: musicdb_user
--

CREATE TABLE musicdb.playlists (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    source character varying(50),
    source_id character varying(255),
    source_url text,
    curator character varying(255),
    follower_count integer,
    is_public boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    metadata jsonb DEFAULT '{}'::jsonb
);


ALTER TABLE musicdb.playlists OWNER TO musicdb_user;

--
-- TOC entry 230 (class 1259 OID 17158)
-- Name: scraping_jobs; Type: TABLE; Schema: musicdb; Owner: musicdb_user
--

CREATE TABLE musicdb.scraping_jobs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    source character varying(50) NOT NULL,
    job_type character varying(50) NOT NULL,
    status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    error_message text,
    items_scraped integer DEFAULT 0,
    items_failed integer DEFAULT 0,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE musicdb.scraping_jobs OWNER TO musicdb_user;

--
-- TOC entry 227 (class 1259 OID 17094)
-- Name: setlist_tracks; Type: TABLE; Schema: musicdb; Owner: musicdb_user
--

CREATE TABLE musicdb.setlist_tracks (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    setlist_id uuid NOT NULL,
    track_id uuid,
    "position" integer NOT NULL,
    track_key character varying(10),
    bpm_live numeric(5,2),
    transition_rating integer,
    is_id boolean DEFAULT false,
    id_text character varying(500),
    notes text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT setlist_tracks_transition_rating_check CHECK (((transition_rating >= 1) AND (transition_rating <= 10)))
);


ALTER TABLE musicdb.setlist_tracks OWNER TO musicdb_user;

--
-- TOC entry 226 (class 1259 OID 17067)
-- Name: setlists; Type: TABLE; Schema: musicdb; Owner: musicdb_user
--

CREATE TABLE musicdb.setlists (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    performer_id uuid,
    event_id uuid,
    set_date timestamp with time zone,
    set_length_minutes integer,
    source character varying(50) NOT NULL,
    source_url text,
    source_id character varying(255),
    is_complete boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    metadata jsonb DEFAULT '{}'::jsonb
);


ALTER TABLE musicdb.setlists OWNER TO musicdb_user;

--
-- TOC entry 224 (class 1259 OID 17035)
-- Name: venues; Type: TABLE; Schema: musicdb; Owner: musicdb_user
--

CREATE TABLE musicdb.venues (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255) NOT NULL,
    city character varying(100),
    state character varying(100),
    country character varying(100),
    latitude numeric(10,8),
    longitude numeric(11,8),
    capacity integer,
    venue_type character varying(50),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    metadata jsonb DEFAULT '{}'::jsonb
);


ALTER TABLE musicdb.venues OWNER TO musicdb_user;

--
-- TOC entry 234 (class 1259 OID 24576)
-- Name: normalized_tracks; Type: TABLE; Schema: public; Owner: musicdb_user
--

CREATE TABLE public.normalized_tracks (
    id character varying(255) NOT NULL,
    source character varying(50) NOT NULL,
    source_id character varying(255) NOT NULL,
    title text NOT NULL,
    artist text NOT NULL,
    album text,
    genre character varying(100),
    label character varying(255),
    release_date timestamp without time zone,
    duration_seconds integer,
    bpm integer,
    key character varying(10),
    url text,
    fingerprint character varying(32) NOT NULL,
    confidence_score double precision NOT NULL,
    metadata jsonb,
    normalized_at timestamp without time zone NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.normalized_tracks OWNER TO musicdb_user;

--
-- TOC entry 236 (class 1259 OID 24591)
-- Name: transformation_results; Type: TABLE; Schema: public; Owner: musicdb_user
--

CREATE TABLE public.transformation_results (
    id integer NOT NULL,
    task_id character varying(255) NOT NULL,
    operation character varying(50) NOT NULL,
    status character varying(20) NOT NULL,
    input_count integer NOT NULL,
    output_count integer NOT NULL,
    processing_time double precision NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.transformation_results OWNER TO musicdb_user;

--
-- TOC entry 235 (class 1259 OID 24590)
-- Name: transformation_results_id_seq; Type: SEQUENCE; Schema: public; Owner: musicdb_user
--

CREATE SEQUENCE public.transformation_results_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.transformation_results_id_seq OWNER TO musicdb_user;

--
-- TOC entry 3991 (class 0 OID 0)
-- Dependencies: 235
-- Name: transformation_results_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: musicdb_user
--

ALTER SEQUENCE public.transformation_results_id_seq OWNED BY public.transformation_results.id;


--
-- TOC entry 240 (class 1259 OID 24609)
-- Name: validation_issues; Type: TABLE; Schema: public; Owner: musicdb_user
--

CREATE TABLE public.validation_issues (
    id integer NOT NULL,
    task_id character varying(255) NOT NULL,
    rule_id character varying(100) NOT NULL,
    rule_name character varying(255) NOT NULL,
    severity character varying(20) NOT NULL,
    field character varying(100),
    message text NOT NULL,
    value text,
    suggestions jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.validation_issues OWNER TO musicdb_user;

--
-- TOC entry 239 (class 1259 OID 24608)
-- Name: validation_issues_id_seq; Type: SEQUENCE; Schema: public; Owner: musicdb_user
--

CREATE SEQUENCE public.validation_issues_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.validation_issues_id_seq OWNER TO musicdb_user;

--
-- TOC entry 3992 (class 0 OID 0)
-- Dependencies: 239
-- Name: validation_issues_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: musicdb_user
--

ALTER SEQUENCE public.validation_issues_id_seq OWNED BY public.validation_issues.id;


--
-- TOC entry 238 (class 1259 OID 24599)
-- Name: validation_results; Type: TABLE; Schema: public; Owner: musicdb_user
--

CREATE TABLE public.validation_results (
    id integer NOT NULL,
    task_id character varying(255) NOT NULL,
    validation_types jsonb NOT NULL,
    status character varying(20) NOT NULL,
    is_valid boolean NOT NULL,
    score double precision NOT NULL,
    total_issues integer NOT NULL,
    error_count integer NOT NULL,
    warning_count integer NOT NULL,
    info_count integer NOT NULL,
    processing_time double precision NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.validation_results OWNER TO musicdb_user;

--
-- TOC entry 237 (class 1259 OID 24598)
-- Name: validation_results_id_seq; Type: SEQUENCE; Schema: public; Owner: musicdb_user
--

CREATE SEQUENCE public.validation_results_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.validation_results_id_seq OWNER TO musicdb_user;

--
-- TOC entry 3993 (class 0 OID 0)
-- Dependencies: 237
-- Name: validation_results_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: musicdb_user
--

ALTER SEQUENCE public.validation_results_id_seq OWNED BY public.validation_results.id;


--
-- TOC entry 3624 (class 2604 OID 24594)
-- Name: transformation_results id; Type: DEFAULT; Schema: public; Owner: musicdb_user
--

ALTER TABLE ONLY public.transformation_results ALTER COLUMN id SET DEFAULT nextval('public.transformation_results_id_seq'::regclass);


--
-- TOC entry 3628 (class 2604 OID 24612)
-- Name: validation_issues id; Type: DEFAULT; Schema: public; Owner: musicdb_user
--

ALTER TABLE ONLY public.validation_issues ALTER COLUMN id SET DEFAULT nextval('public.validation_issues_id_seq'::regclass);


--
-- TOC entry 3626 (class 2604 OID 24602)
-- Name: validation_results id; Type: DEFAULT; Schema: public; Owner: musicdb_user
--

ALTER TABLE ONLY public.validation_results ALTER COLUMN id SET DEFAULT nextval('public.validation_results_id_seq'::regclass);


--
-- TOC entry 3940 (class 0 OID 16995)
-- Dependencies: 222
-- Data for Name: album_tracks; Type: TABLE DATA; Schema: musicdb; Owner: musicdb_user
--

COPY musicdb.album_tracks (id, album_id, track_id, track_number, disc_number, created_at) FROM stdin;
\.


--
-- TOC entry 3939 (class 0 OID 16976)
-- Dependencies: 221
-- Data for Name: albums; Type: TABLE DATA; Schema: musicdb; Owner: musicdb_user
--

COPY musicdb.albums (id, title, artist_id, release_date, label, spotify_id, apple_music_id, total_tracks, album_type, created_at, updated_at, metadata) FROM stdin;
\.


--
-- TOC entry 3936 (class 0 OID 16914)
-- Dependencies: 218
-- Data for Name: artists; Type: TABLE DATA; Schema: musicdb; Owner: musicdb_user
--

COPY musicdb.artists (id, name, normalized_name, aliases, spotify_id, apple_music_id, soundcloud_id, created_at, updated_at, metadata, search_vector) FROM stdin;
\.


--
-- TOC entry 3949 (class 0 OID 17174)
-- Dependencies: 231
-- Data for Name: data_quality_issues; Type: TABLE DATA; Schema: musicdb; Owner: musicdb_user
--

COPY musicdb.data_quality_issues (id, entity_type, entity_id, issue_type, severity, description, suggested_fix, is_resolved, resolved_at, created_at) FROM stdin;
\.


--
-- TOC entry 3960 (class 0 OID 24693)
-- Dependencies: 242
-- Data for Name: edges; Type: TABLE DATA; Schema: musicdb; Owner: musicdb_user
--

COPY musicdb.edges (id, source_id, target_id, weight, edge_type, metadata, created_at) FROM stdin;
\.


--
-- TOC entry 3943 (class 0 OID 17048)
-- Dependencies: 225
-- Data for Name: events; Type: TABLE DATA; Schema: musicdb; Owner: musicdb_user
--

COPY musicdb.events (id, name, venue_id, event_date, event_type, source, source_url, created_at, updated_at, metadata) FROM stdin;
\.


--
-- TOC entry 3959 (class 0 OID 24672)
-- Dependencies: 241
-- Data for Name: nodes; Type: TABLE DATA; Schema: musicdb; Owner: musicdb_user
--

COPY musicdb.nodes (id, track_id, x_position, y_position, metadata, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3941 (class 0 OID 17017)
-- Dependencies: 223
-- Data for Name: performers; Type: TABLE DATA; Schema: musicdb; Owner: musicdb_user
--

COPY musicdb.performers (id, name, normalized_name, artist_id, bio, country, created_at, updated_at, metadata) FROM stdin;
\.


--
-- TOC entry 3947 (class 0 OID 17136)
-- Dependencies: 229
-- Data for Name: playlist_tracks; Type: TABLE DATA; Schema: musicdb; Owner: musicdb_user
--

COPY musicdb.playlist_tracks (id, playlist_id, track_id, "position", added_at, added_by, created_at) FROM stdin;
\.


--
-- TOC entry 3946 (class 0 OID 17121)
-- Dependencies: 228
-- Data for Name: playlists; Type: TABLE DATA; Schema: musicdb; Owner: musicdb_user
--

COPY musicdb.playlists (id, name, description, source, source_id, source_url, curator, follower_count, is_public, created_at, updated_at, metadata) FROM stdin;
\.


--
-- TOC entry 3948 (class 0 OID 17158)
-- Dependencies: 230
-- Data for Name: scraping_jobs; Type: TABLE DATA; Schema: musicdb; Owner: musicdb_user
--

COPY musicdb.scraping_jobs (id, source, job_type, status, started_at, completed_at, error_message, items_scraped, items_failed, metadata, created_at) FROM stdin;
\.


--
-- TOC entry 3945 (class 0 OID 17094)
-- Dependencies: 227
-- Data for Name: setlist_tracks; Type: TABLE DATA; Schema: musicdb; Owner: musicdb_user
--

COPY musicdb.setlist_tracks (id, setlist_id, track_id, "position", track_key, bpm_live, transition_rating, is_id, id_text, notes, created_at) FROM stdin;
\.


--
-- TOC entry 3944 (class 0 OID 17067)
-- Dependencies: 226
-- Data for Name: setlists; Type: TABLE DATA; Schema: musicdb; Owner: musicdb_user
--

COPY musicdb.setlists (id, performer_id, event_id, set_date, set_length_minutes, source, source_url, source_id, is_complete, created_at, updated_at, metadata) FROM stdin;
\.


--
-- TOC entry 3938 (class 0 OID 16952)
-- Dependencies: 220
-- Data for Name: track_artists; Type: TABLE DATA; Schema: musicdb; Owner: musicdb_user
--

COPY musicdb.track_artists (id, track_id, artist_id, role, "position", created_at) FROM stdin;
\.


--
-- TOC entry 3937 (class 0 OID 16929)
-- Dependencies: 219
-- Data for Name: tracks; Type: TABLE DATA; Schema: musicdb; Owner: musicdb_user
--

COPY musicdb.tracks (id, title, normalized_title, isrc, spotify_id, apple_music_id, tidal_id, duration_ms, bpm, key, energy, danceability, valence, release_date, genre, subgenre, mashup_components, is_remix, is_mashup, is_live, is_cover, created_at, updated_at, metadata, search_vector) FROM stdin;
\.


--
-- TOC entry 3942 (class 0 OID 17035)
-- Dependencies: 224
-- Data for Name: venues; Type: TABLE DATA; Schema: musicdb; Owner: musicdb_user
--

COPY musicdb.venues (id, name, city, state, country, latitude, longitude, capacity, venue_type, created_at, updated_at, metadata) FROM stdin;
\.


--
-- TOC entry 3952 (class 0 OID 24576)
-- Dependencies: 234
-- Data for Name: normalized_tracks; Type: TABLE DATA; Schema: public; Owner: musicdb_user
--

COPY public.normalized_tracks (id, source, source_id, title, artist, album, genre, label, release_date, duration_seconds, bpm, key, url, fingerprint, confidence_score, metadata, normalized_at, created_at) FROM stdin;
\.


--
-- TOC entry 3954 (class 0 OID 24591)
-- Dependencies: 236
-- Data for Name: transformation_results; Type: TABLE DATA; Schema: public; Owner: musicdb_user
--

COPY public.transformation_results (id, task_id, operation, status, input_count, output_count, processing_time, created_at) FROM stdin;
\.


--
-- TOC entry 3958 (class 0 OID 24609)
-- Dependencies: 240
-- Data for Name: validation_issues; Type: TABLE DATA; Schema: public; Owner: musicdb_user
--

COPY public.validation_issues (id, task_id, rule_id, rule_name, severity, field, message, value, suggestions, created_at) FROM stdin;
\.


--
-- TOC entry 3956 (class 0 OID 24599)
-- Dependencies: 238
-- Data for Name: validation_results; Type: TABLE DATA; Schema: public; Owner: musicdb_user
--

COPY public.validation_results (id, task_id, validation_types, status, is_valid, score, total_issues, error_count, warning_count, info_count, processing_time, created_at) FROM stdin;
\.


--
-- TOC entry 3994 (class 0 OID 0)
-- Dependencies: 235
-- Name: transformation_results_id_seq; Type: SEQUENCE SET; Schema: public; Owner: musicdb_user
--

SELECT pg_catalog.setval('public.transformation_results_id_seq', 1, false);


--
-- TOC entry 3995 (class 0 OID 0)
-- Dependencies: 239
-- Name: validation_issues_id_seq; Type: SEQUENCE SET; Schema: public; Owner: musicdb_user
--

SELECT pg_catalog.setval('public.validation_issues_id_seq', 1, false);


--
-- TOC entry 3996 (class 0 OID 0)
-- Dependencies: 237
-- Name: validation_results_id_seq; Type: SEQUENCE SET; Schema: public; Owner: musicdb_user
--

SELECT pg_catalog.setval('public.validation_results_id_seq', 1, false);


--
-- TOC entry 3662 (class 2606 OID 16943)
-- Name: tracks tracks_pkey; Type: CONSTRAINT; Schema: musicdb; Owner: musicdb_user
--

ALTER TABLE ONLY musicdb.tracks
    ADD CONSTRAINT tracks_pkey PRIMARY KEY (id);


--
-- TOC entry 232 (class 1259 OID 17188)
-- Name: popular_tracks; Type: MATERIALIZED VIEW; Schema: musicdb; Owner: musicdb_user
--

CREATE MATERIALIZED VIEW musicdb.popular_tracks AS
 SELECT t.id,
    t.title,
    t.normalized_title,
    t.genre,
    t.release_date,
    count(DISTINCT st.setlist_id) AS play_count,
    count(DISTINCT s.performer_id) AS unique_djs,
    avg(st.transition_rating) AS avg_transition_rating,
    max(s.set_date) AS last_played,
    min(s.set_date) AS first_played
   FROM ((musicdb.tracks t
     JOIN musicdb.setlist_tracks st ON ((t.id = st.track_id)))
     JOIN musicdb.setlists s ON ((st.setlist_id = s.id)))
  GROUP BY t.id
  ORDER BY (count(DISTINCT st.setlist_id)) DESC
  WITH NO DATA;


ALTER TABLE musicdb.popular_tracks OWNER TO musicdb_user;

--
-- TOC entry 3676 (class 2606 OID 17004)
-- Name: album_tracks album_tracks_album_id_track_id_key; Type: CONSTRAINT; Schema: musicdb; Owner: musicdb_user
--

ALTER TABLE ONLY musicdb.album_tracks
    ADD CONSTRAINT album_tracks_album_id_track_id_key UNIQUE (album_id, track_id);


--
-- TOC entry 3678 (class 2606 OID 17002)
-- Name: album_tracks album_tracks_pkey; Type: CONSTRAINT; Schema: musicdb; Owner: musicdb_user
--

ALTER TABLE ONLY musicdb.album_tracks
    ADD CONSTRAINT album_tracks_pkey PRIMARY KEY (id);


--
-- TOC entry 3671 (class 2606 OID 16986)
-- Name: albums albums_pkey; Type: CONSTRAINT; Schema: musicdb; Owner: musicdb_user
--

ALTER TABLE ONLY musicdb.albums
    ADD CONSTRAINT albums_pkey PRIMARY KEY (id);


--
-- TOC entry 3646 (class 2606 OID 16924)
-- Name: artists artists_pkey; Type: CONSTRAINT; Schema: musicdb; Owner: musicdb_user
--

ALTER TABLE ONLY musicdb.artists
    ADD CONSTRAINT artists_pkey PRIMARY KEY (id);


--
-- TOC entry 3727 (class 2606 OID 17184)
-- Name: data_quality_issues data_quality_issues_pkey; Type: CONSTRAINT; Schema: musicdb; Owner: musicdb_user
--

ALTER TABLE ONLY musicdb.data_quality_issues
    ADD CONSTRAINT data_quality_issues_pkey PRIMARY KEY (id);


--
-- TOC entry 3759 (class 2606 OID 24706)
-- Name: edges edges_pkey; Type: CONSTRAINT; Schema: musicdb; Owner: musicdb_user
--

ALTER TABLE ONLY musicdb.edges
    ADD CONSTRAINT edges_pkey PRIMARY KEY (id);


--
-- TOC entry 3690 (class 2606 OID 17058)
-- Name: events events_pkey; Type: CONSTRAINT; Schema: musicdb; Owner: musicdb_user
--

ALTER TABLE ONLY musicdb.events
    ADD CONSTRAINT events_pkey PRIMARY KEY (id);


--
-- TOC entry 3757 (class 2606 OID 24684)
-- Name: nodes nodes_pkey; Type: CONSTRAINT; Schema: musicdb; Owner: musicdb_user
--

ALTER TABLE ONLY musicdb.nodes
    ADD CONSTRAINT nodes_pkey PRIMARY KEY (id);


--
-- TOC entry 3684 (class 2606 OID 17027)
-- Name: performers performers_pkey; Type: CONSTRAINT; Schema: musicdb; Owner: musicdb_user
--

ALTER TABLE ONLY musicdb.performers
    ADD CONSTRAINT performers_pkey PRIMARY KEY (id);


--
-- TOC entry 3718 (class 2606 OID 17142)
-- Name: playlist_tracks playlist_tracks_pkey; Type: CONSTRAINT; Schema: musicdb; Owner: musicdb_user
--

ALTER TABLE ONLY musicdb.playlist_tracks
    ADD CONSTRAINT playlist_tracks_pkey PRIMARY KEY (id);


--
-- TOC entry 3720 (class 2606 OID 17144)
-- Name: playlist_tracks playlist_tracks_playlist_id_track_id_key; Type: CONSTRAINT; Schema: musicdb; Owner: musicdb_user
--

ALTER TABLE ONLY musicdb.playlist_tracks
    ADD CONSTRAINT playlist_tracks_playlist_id_track_id_key UNIQUE (playlist_id, track_id);


--
-- TOC entry 3713 (class 2606 OID 17132)
-- Name: playlists playlists_pkey; Type: CONSTRAINT; Schema: musicdb; Owner: musicdb_user
--

ALTER TABLE ONLY musicdb.playlists
    ADD CONSTRAINT playlists_pkey PRIMARY KEY (id);


--
-- TOC entry 3725 (class 2606 OID 17170)
-- Name: scraping_jobs scraping_jobs_pkey; Type: CONSTRAINT; Schema: musicdb; Owner: musicdb_user
--

ALTER TABLE ONLY musicdb.scraping_jobs
    ADD CONSTRAINT scraping_jobs_pkey PRIMARY KEY (id);


--
-- TOC entry 3706 (class 2606 OID 17104)
-- Name: setlist_tracks setlist_tracks_pkey; Type: CONSTRAINT; Schema: musicdb; Owner: musicdb_user
--

ALTER TABLE ONLY musicdb.setlist_tracks
    ADD CONSTRAINT setlist_tracks_pkey PRIMARY KEY (id);


--
-- TOC entry 3708 (class 2606 OID 17106)
-- Name: setlist_tracks setlist_tracks_setlist_id_position_key; Type: CONSTRAINT; Schema: musicdb; Owner: musicdb_user
--

ALTER TABLE ONLY musicdb.setlist_tracks
    ADD CONSTRAINT setlist_tracks_setlist_id_position_key UNIQUE (setlist_id, "position");


--
-- TOC entry 3700 (class 2606 OID 17078)
-- Name: setlists setlists_pkey; Type: CONSTRAINT; Schema: musicdb; Owner: musicdb_user
--

ALTER TABLE ONLY musicdb.setlists
    ADD CONSTRAINT setlists_pkey PRIMARY KEY (id);


--
-- TOC entry 3667 (class 2606 OID 16960)
-- Name: track_artists track_artists_pkey; Type: CONSTRAINT; Schema: musicdb; Owner: musicdb_user
--

ALTER TABLE ONLY musicdb.track_artists
    ADD CONSTRAINT track_artists_pkey PRIMARY KEY (id);


--
-- TOC entry 3669 (class 2606 OID 16962)
-- Name: track_artists track_artists_track_id_artist_id_role_key; Type: CONSTRAINT; Schema: musicdb; Owner: musicdb_user
--

ALTER TABLE ONLY musicdb.track_artists
    ADD CONSTRAINT track_artists_track_id_artist_id_role_key UNIQUE (track_id, artist_id, role);


--
-- TOC entry 3765 (class 2606 OID 24708)
-- Name: edges unique_edge; Type: CONSTRAINT; Schema: musicdb; Owner: musicdb_user
--

ALTER TABLE ONLY musicdb.edges
    ADD CONSTRAINT unique_edge UNIQUE (source_id, target_id, edge_type);


--
-- TOC entry 3688 (class 2606 OID 17045)
-- Name: venues venues_pkey; Type: CONSTRAINT; Schema: musicdb; Owner: musicdb_user
--

ALTER TABLE ONLY musicdb.venues
    ADD CONSTRAINT venues_pkey PRIMARY KEY (id);


--
-- TOC entry 3741 (class 2606 OID 24583)
-- Name: normalized_tracks normalized_tracks_pkey; Type: CONSTRAINT; Schema: public; Owner: musicdb_user
--

ALTER TABLE ONLY public.normalized_tracks
    ADD CONSTRAINT normalized_tracks_pkey PRIMARY KEY (id);


--
-- TOC entry 3743 (class 2606 OID 24585)
-- Name: normalized_tracks normalized_tracks_source_source_id_key; Type: CONSTRAINT; Schema: public; Owner: musicdb_user
--

ALTER TABLE ONLY public.normalized_tracks
    ADD CONSTRAINT normalized_tracks_source_source_id_key UNIQUE (source, source_id);


--
-- TOC entry 3745 (class 2606 OID 24597)
-- Name: transformation_results transformation_results_pkey; Type: CONSTRAINT; Schema: public; Owner: musicdb_user
--

ALTER TABLE ONLY public.transformation_results
    ADD CONSTRAINT transformation_results_pkey PRIMARY KEY (id);


--
-- TOC entry 3752 (class 2606 OID 24617)
-- Name: validation_issues validation_issues_pkey; Type: CONSTRAINT; Schema: public; Owner: musicdb_user
--

ALTER TABLE ONLY public.validation_issues
    ADD CONSTRAINT validation_issues_pkey PRIMARY KEY (id);


--
-- TOC entry 3748 (class 2606 OID 24607)
-- Name: validation_results validation_results_pkey; Type: CONSTRAINT; Schema: public; Owner: musicdb_user
--

ALTER TABLE ONLY public.validation_results
    ADD CONSTRAINT validation_results_pkey PRIMARY KEY (id);


--
-- TOC entry 3679 (class 1259 OID 17015)
-- Name: idx_album_tracks_album_id; Type: INDEX; Schema: musicdb; Owner: musicdb_user
--

CREATE INDEX idx_album_tracks_album_id ON musicdb.album_tracks USING btree (album_id);


--
-- TOC entry 3680 (class 1259 OID 17016)
-- Name: idx_album_tracks_track_id; Type: INDEX; Schema: musicdb; Owner: musicdb_user
--

CREATE INDEX idx_album_tracks_track_id ON musicdb.album_tracks USING btree (track_id);


--
-- TOC entry 3672 (class 1259 OID 16992)
-- Name: idx_albums_artist_id; Type: INDEX; Schema: musicdb; Owner: musicdb_user
--

CREATE INDEX idx_albums_artist_id ON musicdb.albums USING btree (artist_id) WHERE (artist_id IS NOT NULL);


--
-- TOC entry 3673 (class 1259 OID 16993)
-- Name: idx_albums_release_date; Type: INDEX; Schema: musicdb; Owner: musicdb_user
--

CREATE INDEX idx_albums_release_date ON musicdb.albums USING btree (release_date) WHERE (release_date IS NOT NULL);


--
-- TOC entry 3674 (class 1259 OID 16994)
-- Name: idx_albums_spotify_id; Type: INDEX; Schema: musicdb; Owner: musicdb_user
--

CREATE INDEX idx_albums_spotify_id ON musicdb.albums USING btree (spotify_id) WHERE (spotify_id IS NOT NULL);


--
-- TOC entry 3733 (class 1259 OID 17205)
-- Name: idx_artist_collaborations_artists; Type: INDEX; Schema: musicdb; Owner: musicdb_user
--

CREATE INDEX idx_artist_collaborations_artists ON musicdb.artist_collaborations USING btree (artist1_id, artist2_id);


--
-- TOC entry 3734 (class 1259 OID 17204)
-- Name: idx_artist_collaborations_count; Type: INDEX; Schema: musicdb; Owner: musicdb_user
--

CREATE INDEX idx_artist_collaborations_count ON musicdb.artist_collaborations USING btree (collaboration_count DESC);


--
-- TOC entry 3647 (class 1259 OID 16928)
-- Name: idx_artists_metadata; Type: INDEX; Schema: musicdb; Owner: musicdb_user
--

CREATE INDEX idx_artists_metadata ON musicdb.artists USING gin (metadata);


--
-- TOC entry 3648 (class 1259 OID 16926)
-- Name: idx_artists_name_trgm; Type: INDEX; Schema: musicdb; Owner: musicdb_user
--

CREATE INDEX idx_artists_name_trgm ON musicdb.artists USING gin (name public.gin_trgm_ops);


--
-- TOC entry 3649 (class 1259 OID 16925)
-- Name: idx_artists_normalized_name; Type: INDEX; Schema: musicdb; Owner: musicdb_user
--

CREATE UNIQUE INDEX idx_artists_normalized_name ON musicdb.artists USING btree (normalized_name);


--
-- TOC entry 3650 (class 1259 OID 17218)
-- Name: idx_artists_search; Type: INDEX; Schema: musicdb; Owner: musicdb_user
--

CREATE INDEX idx_artists_search ON musicdb.artists USING gin (search_vector);


--
-- TOC entry 3651 (class 1259 OID 16927)
-- Name: idx_artists_spotify_id; Type: INDEX; Schema: musicdb; Owner: musicdb_user
--

CREATE INDEX idx_artists_spotify_id ON musicdb.artists USING btree (spotify_id) WHERE (spotify_id IS NOT NULL);


--
-- TOC entry 3728 (class 1259 OID 17185)
-- Name: idx_data_quality_issues_entity; Type: INDEX; Schema: musicdb; Owner: musicdb_user
--

CREATE INDEX idx_data_quality_issues_entity ON musicdb.data_quality_issues USING btree (entity_type, entity_id);


--
-- TOC entry 3729 (class 1259 OID 17186)
-- Name: idx_data_quality_issues_severity; Type: INDEX; Schema: musicdb; Owner: musicdb_user
--

CREATE INDEX idx_data_quality_issues_severity ON musicdb.data_quality_issues USING btree (severity) WHERE (is_resolved = false);


--
-- TOC entry 3730 (class 1259 OID 17187)
-- Name: idx_data_quality_issues_unresolved; Type: INDEX; Schema: musicdb; Owner: musicdb_user
--

CREATE INDEX idx_data_quality_issues_unresolved ON musicdb.data_quality_issues USING btree (is_resolved) WHERE (is_resolved = false);


--
-- TOC entry 3760 (class 1259 OID 24719)
-- Name: idx_edges_source_target; Type: INDEX; Schema: musicdb; Owner: musicdb_user
--

CREATE INDEX idx_edges_source_target ON musicdb.edges USING btree (source_id, target_id);


--
-- TOC entry 3761 (class 1259 OID 24720)
-- Name: idx_edges_target_source; Type: INDEX; Schema: musicdb; Owner: musicdb_user
--

CREATE INDEX idx_edges_target_source ON musicdb.edges USING btree (target_id, source_id);


--
-- TOC entry 3762 (class 1259 OID 24721)
-- Name: idx_edges_type; Type: INDEX; Schema: musicdb; Owner: musicdb_user
--

CREATE INDEX idx_edges_type ON musicdb.edges USING btree (edge_type);


--
-- TOC entry 3763 (class 1259 OID 24722)
-- Name: idx_edges_weight; Type: INDEX; Schema: musicdb; Owner: musicdb_user
--

CREATE INDEX idx_edges_weight ON musicdb.edges USING btree (weight DESC);


--
-- TOC entry 3691 (class 1259 OID 17065)
-- Name: idx_events_event_date; Type: INDEX; Schema: musicdb; Owner: musicdb_user
--

CREATE INDEX idx_events_event_date ON musicdb.events USING btree (event_date) WHERE (event_date IS NOT NULL);


--
-- TOC entry 3692 (class 1259 OID 17066)
-- Name: idx_events_source; Type: INDEX; Schema: musicdb; Owner: musicdb_user
--

CREATE INDEX idx_events_source ON musicdb.events USING btree (source) WHERE (source IS NOT NULL);


--
-- TOC entry 3693 (class 1259 OID 17064)
-- Name: idx_events_venue_id; Type: INDEX; Schema: musicdb; Owner: musicdb_user
--

CREATE INDEX idx_events_venue_id ON musicdb.events USING btree (venue_id) WHERE (venue_id IS NOT NULL);


--
-- TOC entry 3753 (class 1259 OID 24692)
-- Name: idx_nodes_metadata; Type: INDEX; Schema: musicdb; Owner: musicdb_user
--

CREATE INDEX idx_nodes_metadata ON musicdb.nodes USING gin (metadata);


--
-- TOC entry 3754 (class 1259 OID 24691)
-- Name: idx_nodes_position; Type: INDEX; Schema: musicdb; Owner: musicdb_user
--

CREATE INDEX idx_nodes_position ON musicdb.nodes USING btree (x_position, y_position);


--
-- TOC entry 3755 (class 1259 OID 24690)
-- Name: idx_nodes_track_id; Type: INDEX; Schema: musicdb; Owner: musicdb_user
--

CREATE INDEX idx_nodes_track_id ON musicdb.nodes USING btree (track_id);


--
-- TOC entry 3681 (class 1259 OID 17034)
-- Name: idx_performers_artist_id; Type: INDEX; Schema: musicdb; Owner: musicdb_user
--

CREATE INDEX idx_performers_artist_id ON musicdb.performers USING btree (artist_id) WHERE (artist_id IS NOT NULL);


--
-- TOC entry 3682 (class 1259 OID 17033)
-- Name: idx_performers_normalized_name; Type: INDEX; Schema: musicdb; Owner: musicdb_user
--

CREATE UNIQUE INDEX idx_performers_normalized_name ON musicdb.performers USING btree (normalized_name);


--
-- TOC entry 3714 (class 1259 OID 17155)
-- Name: idx_playlist_tracks_playlist_id; Type: INDEX; Schema: musicdb; Owner: musicdb_user
--

CREATE INDEX idx_playlist_tracks_playlist_id ON musicdb.playlist_tracks USING btree (playlist_id);


--
-- TOC entry 3715 (class 1259 OID 17157)
-- Name: idx_playlist_tracks_position; Type: INDEX; Schema: musicdb; Owner: musicdb_user
--

CREATE INDEX idx_playlist_tracks_position ON musicdb.playlist_tracks USING btree (playlist_id, "position");


--
-- TOC entry 3716 (class 1259 OID 17156)
-- Name: idx_playlist_tracks_track_id; Type: INDEX; Schema: musicdb; Owner: musicdb_user
--

CREATE INDEX idx_playlist_tracks_track_id ON musicdb.playlist_tracks USING btree (track_id);


--
-- TOC entry 3709 (class 1259 OID 17135)
-- Name: idx_playlists_curator; Type: INDEX; Schema: musicdb; Owner: musicdb_user
--

CREATE INDEX idx_playlists_curator ON musicdb.playlists USING btree (curator) WHERE (curator IS NOT NULL);


--
-- TOC entry 3710 (class 1259 OID 17133)
-- Name: idx_playlists_source; Type: INDEX; Schema: musicdb; Owner: musicdb_user
--

CREATE INDEX idx_playlists_source ON musicdb.playlists USING btree (source) WHERE (source IS NOT NULL);


--
-- TOC entry 3711 (class 1259 OID 17134)
-- Name: idx_playlists_source_id; Type: INDEX; Schema: musicdb; Owner: musicdb_user
--

CREATE UNIQUE INDEX idx_playlists_source_id ON musicdb.playlists USING btree (source, source_id) WHERE (source_id IS NOT NULL);


--
-- TOC entry 3731 (class 1259 OID 17195)
-- Name: idx_popular_tracks_id; Type: INDEX; Schema: musicdb; Owner: musicdb_user
--

CREATE UNIQUE INDEX idx_popular_tracks_id ON musicdb.popular_tracks USING btree (id);


--
-- TOC entry 3732 (class 1259 OID 17196)
-- Name: idx_popular_tracks_play_count; Type: INDEX; Schema: musicdb; Owner: musicdb_user
--

CREATE INDEX idx_popular_tracks_play_count ON musicdb.popular_tracks USING btree (play_count DESC);


--
-- TOC entry 3721 (class 1259 OID 17173)
-- Name: idx_scraping_jobs_created_at; Type: INDEX; Schema: musicdb; Owner: musicdb_user
--

CREATE INDEX idx_scraping_jobs_created_at ON musicdb.scraping_jobs USING btree (created_at DESC);


--
-- TOC entry 3722 (class 1259 OID 17171)
-- Name: idx_scraping_jobs_source; Type: INDEX; Schema: musicdb; Owner: musicdb_user
--

CREATE INDEX idx_scraping_jobs_source ON musicdb.scraping_jobs USING btree (source);


--
-- TOC entry 3723 (class 1259 OID 17172)
-- Name: idx_scraping_jobs_status; Type: INDEX; Schema: musicdb; Owner: musicdb_user
--

CREATE INDEX idx_scraping_jobs_status ON musicdb.scraping_jobs USING btree (status);


--
-- TOC entry 3701 (class 1259 OID 17120)
-- Name: idx_setlist_tracks_is_id; Type: INDEX; Schema: musicdb; Owner: musicdb_user
--

CREATE INDEX idx_setlist_tracks_is_id ON musicdb.setlist_tracks USING btree (is_id) WHERE (is_id = true);


--
-- TOC entry 3702 (class 1259 OID 17119)
-- Name: idx_setlist_tracks_position; Type: INDEX; Schema: musicdb; Owner: musicdb_user
--

CREATE INDEX idx_setlist_tracks_position ON musicdb.setlist_tracks USING btree (setlist_id, "position");


--
-- TOC entry 3703 (class 1259 OID 17117)
-- Name: idx_setlist_tracks_setlist_id; Type: INDEX; Schema: musicdb; Owner: musicdb_user
--

CREATE INDEX idx_setlist_tracks_setlist_id ON musicdb.setlist_tracks USING btree (setlist_id);


--
-- TOC entry 3704 (class 1259 OID 17118)
-- Name: idx_setlist_tracks_track_id; Type: INDEX; Schema: musicdb; Owner: musicdb_user
--

CREATE INDEX idx_setlist_tracks_track_id ON musicdb.setlist_tracks USING btree (track_id) WHERE (track_id IS NOT NULL);


--
-- TOC entry 3694 (class 1259 OID 17090)
-- Name: idx_setlists_event_id; Type: INDEX; Schema: musicdb; Owner: musicdb_user
--

CREATE INDEX idx_setlists_event_id ON musicdb.setlists USING btree (event_id) WHERE (event_id IS NOT NULL);


--
-- TOC entry 3695 (class 1259 OID 17089)
-- Name: idx_setlists_performer_id; Type: INDEX; Schema: musicdb; Owner: musicdb_user
--

CREATE INDEX idx_setlists_performer_id ON musicdb.setlists USING btree (performer_id) WHERE (performer_id IS NOT NULL);


--
-- TOC entry 3696 (class 1259 OID 17091)
-- Name: idx_setlists_set_date; Type: INDEX; Schema: musicdb; Owner: musicdb_user
--

CREATE INDEX idx_setlists_set_date ON musicdb.setlists USING btree (set_date) WHERE (set_date IS NOT NULL);


--
-- TOC entry 3697 (class 1259 OID 17092)
-- Name: idx_setlists_source; Type: INDEX; Schema: musicdb; Owner: musicdb_user
--

CREATE INDEX idx_setlists_source ON musicdb.setlists USING btree (source);


--
-- TOC entry 3698 (class 1259 OID 17093)
-- Name: idx_setlists_source_id; Type: INDEX; Schema: musicdb; Owner: musicdb_user
--

CREATE UNIQUE INDEX idx_setlists_source_id ON musicdb.setlists USING btree (source, source_id) WHERE (source_id IS NOT NULL);


--
-- TOC entry 3663 (class 1259 OID 16974)
-- Name: idx_track_artists_artist_id; Type: INDEX; Schema: musicdb; Owner: musicdb_user
--

CREATE INDEX idx_track_artists_artist_id ON musicdb.track_artists USING btree (artist_id);


--
-- TOC entry 3664 (class 1259 OID 16975)
-- Name: idx_track_artists_role; Type: INDEX; Schema: musicdb; Owner: musicdb_user
--

CREATE INDEX idx_track_artists_role ON musicdb.track_artists USING btree (role);


--
-- TOC entry 3665 (class 1259 OID 16973)
-- Name: idx_track_artists_track_id; Type: INDEX; Schema: musicdb; Owner: musicdb_user
--

CREATE INDEX idx_track_artists_track_id ON musicdb.track_artists USING btree (track_id);


--
-- TOC entry 3652 (class 1259 OID 16948)
-- Name: idx_tracks_genre; Type: INDEX; Schema: musicdb; Owner: musicdb_user
--

CREATE INDEX idx_tracks_genre ON musicdb.tracks USING btree (genre) WHERE (genre IS NOT NULL);


--
-- TOC entry 3653 (class 1259 OID 16944)
-- Name: idx_tracks_isrc; Type: INDEX; Schema: musicdb; Owner: musicdb_user
--

CREATE UNIQUE INDEX idx_tracks_isrc ON musicdb.tracks USING btree (isrc) WHERE (isrc IS NOT NULL);


--
-- TOC entry 3654 (class 1259 OID 16950)
-- Name: idx_tracks_mashup_components; Type: INDEX; Schema: musicdb; Owner: musicdb_user
--

CREATE INDEX idx_tracks_mashup_components ON musicdb.tracks USING gin (mashup_components) WHERE (mashup_components IS NOT NULL);


--
-- TOC entry 3655 (class 1259 OID 16951)
-- Name: idx_tracks_metadata; Type: INDEX; Schema: musicdb; Owner: musicdb_user
--

CREATE INDEX idx_tracks_metadata ON musicdb.tracks USING gin (metadata);


--
-- TOC entry 3656 (class 1259 OID 16945)
-- Name: idx_tracks_normalized_title; Type: INDEX; Schema: musicdb; Owner: musicdb_user
--

CREATE INDEX idx_tracks_normalized_title ON musicdb.tracks USING btree (normalized_title);


--
-- TOC entry 3657 (class 1259 OID 16949)
-- Name: idx_tracks_release_date; Type: INDEX; Schema: musicdb; Owner: musicdb_user
--

CREATE INDEX idx_tracks_release_date ON musicdb.tracks USING btree (release_date) WHERE (release_date IS NOT NULL);


--
-- TOC entry 3658 (class 1259 OID 17217)
-- Name: idx_tracks_search; Type: INDEX; Schema: musicdb; Owner: musicdb_user
--

CREATE INDEX idx_tracks_search ON musicdb.tracks USING gin (search_vector);


--
-- TOC entry 3659 (class 1259 OID 16947)
-- Name: idx_tracks_spotify_id; Type: INDEX; Schema: musicdb; Owner: musicdb_user
--

CREATE INDEX idx_tracks_spotify_id ON musicdb.tracks USING btree (spotify_id) WHERE (spotify_id IS NOT NULL);


--
-- TOC entry 3660 (class 1259 OID 16946)
-- Name: idx_tracks_title_trgm; Type: INDEX; Schema: musicdb; Owner: musicdb_user
--

CREATE INDEX idx_tracks_title_trgm ON musicdb.tracks USING gin (title public.gin_trgm_ops);


--
-- TOC entry 3685 (class 1259 OID 17047)
-- Name: idx_venues_geo; Type: INDEX; Schema: musicdb; Owner: musicdb_user
--

CREATE INDEX idx_venues_geo ON musicdb.venues USING btree (latitude, longitude) WHERE ((latitude IS NOT NULL) AND (longitude IS NOT NULL));


--
-- TOC entry 3686 (class 1259 OID 17046)
-- Name: idx_venues_location; Type: INDEX; Schema: musicdb; Owner: musicdb_user
--

CREATE INDEX idx_venues_location ON musicdb.venues USING btree (country, state, city);


--
-- TOC entry 3735 (class 1259 OID 24588)
-- Name: idx_normalized_tracks_artist; Type: INDEX; Schema: public; Owner: musicdb_user
--

CREATE INDEX idx_normalized_tracks_artist ON public.normalized_tracks USING btree (artist);


--
-- TOC entry 3736 (class 1259 OID 24586)
-- Name: idx_normalized_tracks_fingerprint; Type: INDEX; Schema: public; Owner: musicdb_user
--

CREATE INDEX idx_normalized_tracks_fingerprint ON public.normalized_tracks USING btree (fingerprint);


--
-- TOC entry 3737 (class 1259 OID 24589)
-- Name: idx_normalized_tracks_genre; Type: INDEX; Schema: public; Owner: musicdb_user
--

CREATE INDEX idx_normalized_tracks_genre ON public.normalized_tracks USING btree (genre);


--
-- TOC entry 3738 (class 1259 OID 24587)
-- Name: idx_normalized_tracks_source; Type: INDEX; Schema: public; Owner: musicdb_user
--

CREATE INDEX idx_normalized_tracks_source ON public.normalized_tracks USING btree (source);


--
-- TOC entry 3739 (class 1259 OID 24723)
-- Name: idx_test_table; Type: INDEX; Schema: public; Owner: musicdb_user
--

CREATE INDEX idx_test_table ON public.normalized_tracks USING btree (fingerprint);


--
-- TOC entry 3749 (class 1259 OID 24724)
-- Name: idx_validation_issues_severity; Type: INDEX; Schema: public; Owner: musicdb_user
--

CREATE INDEX idx_validation_issues_severity ON public.validation_issues USING btree (severity);


--
-- TOC entry 3750 (class 1259 OID 24619)
-- Name: idx_validation_issues_task_id; Type: INDEX; Schema: public; Owner: musicdb_user
--

CREATE INDEX idx_validation_issues_task_id ON public.validation_issues USING btree (task_id);


--
-- TOC entry 3746 (class 1259 OID 24618)
-- Name: idx_validation_results_task_id; Type: INDEX; Schema: public; Owner: musicdb_user
--

CREATE INDEX idx_validation_results_task_id ON public.validation_results USING btree (task_id);


--
-- TOC entry 3786 (class 2620 OID 17209)
-- Name: albums update_albums_updated_at; Type: TRIGGER; Schema: musicdb; Owner: musicdb_user
--

CREATE TRIGGER update_albums_updated_at BEFORE UPDATE ON musicdb.albums FOR EACH ROW EXECUTE FUNCTION musicdb.update_updated_at_column();


--
-- TOC entry 3782 (class 2620 OID 17222)
-- Name: artists update_artist_search_vector_trigger; Type: TRIGGER; Schema: musicdb; Owner: musicdb_user
--

CREATE TRIGGER update_artist_search_vector_trigger BEFORE INSERT OR UPDATE ON musicdb.artists FOR EACH ROW EXECUTE FUNCTION musicdb.update_artist_search_vector();


--
-- TOC entry 3783 (class 2620 OID 17207)
-- Name: artists update_artists_updated_at; Type: TRIGGER; Schema: musicdb; Owner: musicdb_user
--

CREATE TRIGGER update_artists_updated_at BEFORE UPDATE ON musicdb.artists FOR EACH ROW EXECUTE FUNCTION musicdb.update_updated_at_column();


--
-- TOC entry 3789 (class 2620 OID 17212)
-- Name: events update_events_updated_at; Type: TRIGGER; Schema: musicdb; Owner: musicdb_user
--

CREATE TRIGGER update_events_updated_at BEFORE UPDATE ON musicdb.events FOR EACH ROW EXECUTE FUNCTION musicdb.update_updated_at_column();


--
-- TOC entry 3787 (class 2620 OID 17210)
-- Name: performers update_performers_updated_at; Type: TRIGGER; Schema: musicdb; Owner: musicdb_user
--

CREATE TRIGGER update_performers_updated_at BEFORE UPDATE ON musicdb.performers FOR EACH ROW EXECUTE FUNCTION musicdb.update_updated_at_column();


--
-- TOC entry 3791 (class 2620 OID 17214)
-- Name: playlists update_playlists_updated_at; Type: TRIGGER; Schema: musicdb; Owner: musicdb_user
--

CREATE TRIGGER update_playlists_updated_at BEFORE UPDATE ON musicdb.playlists FOR EACH ROW EXECUTE FUNCTION musicdb.update_updated_at_column();


--
-- TOC entry 3790 (class 2620 OID 17213)
-- Name: setlists update_setlists_updated_at; Type: TRIGGER; Schema: musicdb; Owner: musicdb_user
--

CREATE TRIGGER update_setlists_updated_at BEFORE UPDATE ON musicdb.setlists FOR EACH ROW EXECUTE FUNCTION musicdb.update_updated_at_column();


--
-- TOC entry 3784 (class 2620 OID 17220)
-- Name: tracks update_track_search_vector_trigger; Type: TRIGGER; Schema: musicdb; Owner: musicdb_user
--

CREATE TRIGGER update_track_search_vector_trigger BEFORE INSERT OR UPDATE ON musicdb.tracks FOR EACH ROW EXECUTE FUNCTION musicdb.update_track_search_vector();


--
-- TOC entry 3785 (class 2620 OID 17208)
-- Name: tracks update_tracks_updated_at; Type: TRIGGER; Schema: musicdb; Owner: musicdb_user
--

CREATE TRIGGER update_tracks_updated_at BEFORE UPDATE ON musicdb.tracks FOR EACH ROW EXECUTE FUNCTION musicdb.update_updated_at_column();


--
-- TOC entry 3788 (class 2620 OID 17211)
-- Name: venues update_venues_updated_at; Type: TRIGGER; Schema: musicdb; Owner: musicdb_user
--

CREATE TRIGGER update_venues_updated_at BEFORE UPDATE ON musicdb.venues FOR EACH ROW EXECUTE FUNCTION musicdb.update_updated_at_column();


--
-- TOC entry 3769 (class 2606 OID 17005)
-- Name: album_tracks album_tracks_album_id_fkey; Type: FK CONSTRAINT; Schema: musicdb; Owner: musicdb_user
--

ALTER TABLE ONLY musicdb.album_tracks
    ADD CONSTRAINT album_tracks_album_id_fkey FOREIGN KEY (album_id) REFERENCES musicdb.albums(id) ON DELETE CASCADE;


--
-- TOC entry 3770 (class 2606 OID 17010)
-- Name: album_tracks album_tracks_track_id_fkey; Type: FK CONSTRAINT; Schema: musicdb; Owner: musicdb_user
--

ALTER TABLE ONLY musicdb.album_tracks
    ADD CONSTRAINT album_tracks_track_id_fkey FOREIGN KEY (track_id) REFERENCES musicdb.tracks(id) ON DELETE CASCADE;


--
-- TOC entry 3768 (class 2606 OID 16987)
-- Name: albums albums_artist_id_fkey; Type: FK CONSTRAINT; Schema: musicdb; Owner: musicdb_user
--

ALTER TABLE ONLY musicdb.albums
    ADD CONSTRAINT albums_artist_id_fkey FOREIGN KEY (artist_id) REFERENCES musicdb.artists(id);


--
-- TOC entry 3780 (class 2606 OID 24709)
-- Name: edges edges_source_id_fkey; Type: FK CONSTRAINT; Schema: musicdb; Owner: musicdb_user
--

ALTER TABLE ONLY musicdb.edges
    ADD CONSTRAINT edges_source_id_fkey FOREIGN KEY (source_id) REFERENCES musicdb.nodes(id) ON DELETE CASCADE;


--
-- TOC entry 3781 (class 2606 OID 24714)
-- Name: edges edges_target_id_fkey; Type: FK CONSTRAINT; Schema: musicdb; Owner: musicdb_user
--

ALTER TABLE ONLY musicdb.edges
    ADD CONSTRAINT edges_target_id_fkey FOREIGN KEY (target_id) REFERENCES musicdb.nodes(id) ON DELETE CASCADE;


--
-- TOC entry 3772 (class 2606 OID 17059)
-- Name: events events_venue_id_fkey; Type: FK CONSTRAINT; Schema: musicdb; Owner: musicdb_user
--

ALTER TABLE ONLY musicdb.events
    ADD CONSTRAINT events_venue_id_fkey FOREIGN KEY (venue_id) REFERENCES musicdb.venues(id);


--
-- TOC entry 3779 (class 2606 OID 24685)
-- Name: nodes fk_nodes_track_id; Type: FK CONSTRAINT; Schema: musicdb; Owner: musicdb_user
--

ALTER TABLE ONLY musicdb.nodes
    ADD CONSTRAINT fk_nodes_track_id FOREIGN KEY (track_id) REFERENCES musicdb.tracks(id) ON DELETE CASCADE;


--
-- TOC entry 3771 (class 2606 OID 17028)
-- Name: performers performers_artist_id_fkey; Type: FK CONSTRAINT; Schema: musicdb; Owner: musicdb_user
--

ALTER TABLE ONLY musicdb.performers
    ADD CONSTRAINT performers_artist_id_fkey FOREIGN KEY (artist_id) REFERENCES musicdb.artists(id);


--
-- TOC entry 3777 (class 2606 OID 17145)
-- Name: playlist_tracks playlist_tracks_playlist_id_fkey; Type: FK CONSTRAINT; Schema: musicdb; Owner: musicdb_user
--

ALTER TABLE ONLY musicdb.playlist_tracks
    ADD CONSTRAINT playlist_tracks_playlist_id_fkey FOREIGN KEY (playlist_id) REFERENCES musicdb.playlists(id) ON DELETE CASCADE;


--
-- TOC entry 3778 (class 2606 OID 17150)
-- Name: playlist_tracks playlist_tracks_track_id_fkey; Type: FK CONSTRAINT; Schema: musicdb; Owner: musicdb_user
--

ALTER TABLE ONLY musicdb.playlist_tracks
    ADD CONSTRAINT playlist_tracks_track_id_fkey FOREIGN KEY (track_id) REFERENCES musicdb.tracks(id) ON DELETE CASCADE;


--
-- TOC entry 3775 (class 2606 OID 17107)
-- Name: setlist_tracks setlist_tracks_setlist_id_fkey; Type: FK CONSTRAINT; Schema: musicdb; Owner: musicdb_user
--

ALTER TABLE ONLY musicdb.setlist_tracks
    ADD CONSTRAINT setlist_tracks_setlist_id_fkey FOREIGN KEY (setlist_id) REFERENCES musicdb.setlists(id) ON DELETE CASCADE;


--
-- TOC entry 3776 (class 2606 OID 17112)
-- Name: setlist_tracks setlist_tracks_track_id_fkey; Type: FK CONSTRAINT; Schema: musicdb; Owner: musicdb_user
--

ALTER TABLE ONLY musicdb.setlist_tracks
    ADD CONSTRAINT setlist_tracks_track_id_fkey FOREIGN KEY (track_id) REFERENCES musicdb.tracks(id);


--
-- TOC entry 3773 (class 2606 OID 17084)
-- Name: setlists setlists_event_id_fkey; Type: FK CONSTRAINT; Schema: musicdb; Owner: musicdb_user
--

ALTER TABLE ONLY musicdb.setlists
    ADD CONSTRAINT setlists_event_id_fkey FOREIGN KEY (event_id) REFERENCES musicdb.events(id);


--
-- TOC entry 3774 (class 2606 OID 17079)
-- Name: setlists setlists_performer_id_fkey; Type: FK CONSTRAINT; Schema: musicdb; Owner: musicdb_user
--

ALTER TABLE ONLY musicdb.setlists
    ADD CONSTRAINT setlists_performer_id_fkey FOREIGN KEY (performer_id) REFERENCES musicdb.performers(id);


--
-- TOC entry 3766 (class 2606 OID 16968)
-- Name: track_artists track_artists_artist_id_fkey; Type: FK CONSTRAINT; Schema: musicdb; Owner: musicdb_user
--

ALTER TABLE ONLY musicdb.track_artists
    ADD CONSTRAINT track_artists_artist_id_fkey FOREIGN KEY (artist_id) REFERENCES musicdb.artists(id) ON DELETE CASCADE;


--
-- TOC entry 3767 (class 2606 OID 16963)
-- Name: track_artists track_artists_track_id_fkey; Type: FK CONSTRAINT; Schema: musicdb; Owner: musicdb_user
--

ALTER TABLE ONLY musicdb.track_artists
    ADD CONSTRAINT track_artists_track_id_fkey FOREIGN KEY (track_id) REFERENCES musicdb.tracks(id) ON DELETE CASCADE;


--
-- TOC entry 3966 (class 0 OID 0)
-- Dependencies: 9
-- Name: SCHEMA musicdb; Type: ACL; Schema: -; Owner: musicdb_user
--

GRANT USAGE ON SCHEMA musicdb TO musicdb_readonly;
GRANT ALL ON SCHEMA musicdb TO musicdb_app;


--
-- TOC entry 3970 (class 0 OID 0)
-- Dependencies: 387
-- Name: FUNCTION bulk_insert_edges(edge_data jsonb); Type: ACL; Schema: musicdb; Owner: musicdb_user
--

GRANT ALL ON FUNCTION musicdb.bulk_insert_edges(edge_data jsonb) TO musicdb_app;


--
-- TOC entry 3971 (class 0 OID 0)
-- Dependencies: 390
-- Name: FUNCTION bulk_insert_nodes(node_data jsonb); Type: ACL; Schema: musicdb; Owner: musicdb_user
--

GRANT ALL ON FUNCTION musicdb.bulk_insert_nodes(node_data jsonb) TO musicdb_app;


--
-- TOC entry 3972 (class 0 OID 0)
-- Dependencies: 388
-- Name: FUNCTION calculate_graph_metrics(); Type: ACL; Schema: musicdb; Owner: musicdb_user
--

GRANT ALL ON FUNCTION musicdb.calculate_graph_metrics() TO musicdb_app;


--
-- TOC entry 3973 (class 0 OID 0)
-- Dependencies: 389
-- Name: FUNCTION refresh_graph_views(); Type: ACL; Schema: musicdb; Owner: musicdb_user
--

GRANT ALL ON FUNCTION musicdb.refresh_graph_views() TO musicdb_app;


--
-- TOC entry 3974 (class 0 OID 0)
-- Dependencies: 222
-- Name: TABLE album_tracks; Type: ACL; Schema: musicdb; Owner: musicdb_user
--

GRANT SELECT ON TABLE musicdb.album_tracks TO musicdb_readonly;
GRANT ALL ON TABLE musicdb.album_tracks TO musicdb_app;


--
-- TOC entry 3975 (class 0 OID 0)
-- Dependencies: 221
-- Name: TABLE albums; Type: ACL; Schema: musicdb; Owner: musicdb_user
--

GRANT SELECT ON TABLE musicdb.albums TO musicdb_readonly;
GRANT ALL ON TABLE musicdb.albums TO musicdb_app;


--
-- TOC entry 3976 (class 0 OID 0)
-- Dependencies: 218
-- Name: TABLE artists; Type: ACL; Schema: musicdb; Owner: musicdb_user
--

GRANT SELECT ON TABLE musicdb.artists TO musicdb_readonly;
GRANT ALL ON TABLE musicdb.artists TO musicdb_app;


--
-- TOC entry 3977 (class 0 OID 0)
-- Dependencies: 220
-- Name: TABLE track_artists; Type: ACL; Schema: musicdb; Owner: musicdb_user
--

GRANT SELECT ON TABLE musicdb.track_artists TO musicdb_readonly;
GRANT ALL ON TABLE musicdb.track_artists TO musicdb_app;


--
-- TOC entry 3978 (class 0 OID 0)
-- Dependencies: 219
-- Name: TABLE tracks; Type: ACL; Schema: musicdb; Owner: musicdb_user
--

GRANT SELECT ON TABLE musicdb.tracks TO musicdb_readonly;
GRANT ALL ON TABLE musicdb.tracks TO musicdb_app;


--
-- TOC entry 3979 (class 0 OID 0)
-- Dependencies: 233
-- Name: TABLE artist_collaborations; Type: ACL; Schema: musicdb; Owner: musicdb_user
--

GRANT SELECT ON TABLE musicdb.artist_collaborations TO musicdb_readonly;
GRANT ALL ON TABLE musicdb.artist_collaborations TO musicdb_app;


--
-- TOC entry 3980 (class 0 OID 0)
-- Dependencies: 231
-- Name: TABLE data_quality_issues; Type: ACL; Schema: musicdb; Owner: musicdb_user
--

GRANT SELECT ON TABLE musicdb.data_quality_issues TO musicdb_readonly;
GRANT ALL ON TABLE musicdb.data_quality_issues TO musicdb_app;


--
-- TOC entry 3981 (class 0 OID 0)
-- Dependencies: 242
-- Name: TABLE edges; Type: ACL; Schema: musicdb; Owner: musicdb_user
--

GRANT SELECT ON TABLE musicdb.edges TO musicdb_readonly;
GRANT ALL ON TABLE musicdb.edges TO musicdb_app;


--
-- TOC entry 3982 (class 0 OID 0)
-- Dependencies: 225
-- Name: TABLE events; Type: ACL; Schema: musicdb; Owner: musicdb_user
--

GRANT SELECT ON TABLE musicdb.events TO musicdb_readonly;
GRANT ALL ON TABLE musicdb.events TO musicdb_app;


--
-- TOC entry 3983 (class 0 OID 0)
-- Dependencies: 241
-- Name: TABLE nodes; Type: ACL; Schema: musicdb; Owner: musicdb_user
--

GRANT SELECT ON TABLE musicdb.nodes TO musicdb_readonly;
GRANT ALL ON TABLE musicdb.nodes TO musicdb_app;


--
-- TOC entry 3984 (class 0 OID 0)
-- Dependencies: 223
-- Name: TABLE performers; Type: ACL; Schema: musicdb; Owner: musicdb_user
--

GRANT SELECT ON TABLE musicdb.performers TO musicdb_readonly;
GRANT ALL ON TABLE musicdb.performers TO musicdb_app;


--
-- TOC entry 3985 (class 0 OID 0)
-- Dependencies: 229
-- Name: TABLE playlist_tracks; Type: ACL; Schema: musicdb; Owner: musicdb_user
--

GRANT SELECT ON TABLE musicdb.playlist_tracks TO musicdb_readonly;
GRANT ALL ON TABLE musicdb.playlist_tracks TO musicdb_app;


--
-- TOC entry 3986 (class 0 OID 0)
-- Dependencies: 228
-- Name: TABLE playlists; Type: ACL; Schema: musicdb; Owner: musicdb_user
--

GRANT SELECT ON TABLE musicdb.playlists TO musicdb_readonly;
GRANT ALL ON TABLE musicdb.playlists TO musicdb_app;


--
-- TOC entry 3987 (class 0 OID 0)
-- Dependencies: 230
-- Name: TABLE scraping_jobs; Type: ACL; Schema: musicdb; Owner: musicdb_user
--

GRANT SELECT ON TABLE musicdb.scraping_jobs TO musicdb_readonly;
GRANT ALL ON TABLE musicdb.scraping_jobs TO musicdb_app;


--
-- TOC entry 3988 (class 0 OID 0)
-- Dependencies: 227
-- Name: TABLE setlist_tracks; Type: ACL; Schema: musicdb; Owner: musicdb_user
--

GRANT SELECT ON TABLE musicdb.setlist_tracks TO musicdb_readonly;
GRANT ALL ON TABLE musicdb.setlist_tracks TO musicdb_app;


--
-- TOC entry 3989 (class 0 OID 0)
-- Dependencies: 226
-- Name: TABLE setlists; Type: ACL; Schema: musicdb; Owner: musicdb_user
--

GRANT SELECT ON TABLE musicdb.setlists TO musicdb_readonly;
GRANT ALL ON TABLE musicdb.setlists TO musicdb_app;


--
-- TOC entry 3990 (class 0 OID 0)
-- Dependencies: 224
-- Name: TABLE venues; Type: ACL; Schema: musicdb; Owner: musicdb_user
--

GRANT SELECT ON TABLE musicdb.venues TO musicdb_readonly;
GRANT ALL ON TABLE musicdb.venues TO musicdb_app;


--
-- TOC entry 3997 (class 0 OID 0)
-- Dependencies: 232
-- Name: TABLE popular_tracks; Type: ACL; Schema: musicdb; Owner: musicdb_user
--

GRANT SELECT ON TABLE musicdb.popular_tracks TO musicdb_readonly;
GRANT ALL ON TABLE musicdb.popular_tracks TO musicdb_app;


--
-- TOC entry 2338 (class 826 OID 17226)
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: musicdb; Owner: musicdb_user
--

ALTER DEFAULT PRIVILEGES FOR ROLE musicdb_user IN SCHEMA musicdb GRANT ALL ON SEQUENCES  TO musicdb_app;


--
-- TOC entry 2337 (class 826 OID 17224)
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: musicdb; Owner: musicdb_user
--

ALTER DEFAULT PRIVILEGES FOR ROLE musicdb_user IN SCHEMA musicdb GRANT SELECT ON TABLES  TO musicdb_readonly;
ALTER DEFAULT PRIVILEGES FOR ROLE musicdb_user IN SCHEMA musicdb GRANT ALL ON TABLES  TO musicdb_app;


--
-- TOC entry 3951 (class 0 OID 17197)
-- Dependencies: 233 3962
-- Name: artist_collaborations; Type: MATERIALIZED VIEW DATA; Schema: musicdb; Owner: musicdb_user
--

REFRESH MATERIALIZED VIEW musicdb.artist_collaborations;


--
-- TOC entry 3950 (class 0 OID 17188)
-- Dependencies: 232 3962
-- Name: popular_tracks; Type: MATERIALIZED VIEW DATA; Schema: musicdb; Owner: musicdb_user
--

REFRESH MATERIALIZED VIEW musicdb.popular_tracks;


-- Completed on 2025-08-19 12:25:34 UTC

--
-- PostgreSQL database dump complete
--

\unrestrict DZSddrVULP5X9xIOR3qhJw4qhkHhQU8w9SLp1ezTO01n1PdGAAtMKWiCHmRtWyL

